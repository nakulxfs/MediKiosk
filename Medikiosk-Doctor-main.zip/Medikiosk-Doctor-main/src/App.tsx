import { useState, useEffect } from 'react';
import Header from './components/Header';
import KioskIntakeView from './components/KioskIntakeView';
import DocumentScannerView from './components/DocumentScannerView';
import LlamaAuditView from './components/LlamaAuditView';
import PhysicianSummaryView from './components/PhysicianSummaryView';
import TriageAlertModal from './components/TriageAlertModal';
import ScenarioDrawer from './components/ScenarioDrawer';
import ApiKeyModal from './components/ApiKeyModal';
import {
  DepartmentType,
  MediKioskPayload,
  DialogueMessage,
  LlamaAuditReport,
} from './types';
import { SampleScenario } from './data/sampleScenarios';
import {
  MessageSquare,
  FileText,
  Cpu,
  Stethoscope,
  ShieldCheck,
  AlertTriangle,
  KeyRound,
} from 'lucide-react';

function createDefaultPayload(dept: DepartmentType): MediKioskPayload {
  const isAyush = dept === 'AYUSH';
  return {
    system_state: {
      mode: 'Dialogue',
      department: dept,
      session_complete: false,
    },
    triage: {
      red_flag_detected: false,
      urgency_level: 'Routine',
      alert_reason: null,
    },
    interaction_output: {
      spoken_prompt: isAyush
        ? 'Namaste. MediKiosk AYUSH OPD me aapka swagat hai. Kripya batayein aapko kya takleef hai?'
        : 'Namaste. MediKiosk OPD me aapka swagat hai. Kripya batayein aapko kya pareshani hai?',
      touch_options: isAyush
        ? [
            'Pet me gas / apach (Indigestion)',
            'Jodo me dard (Joint Pain)',
            'Twacha vikar (Skin rash)',
            'Kuch aur takleef (Other)',
          ]
        : [
            'Pet me dard ya ulti (Stomach pain)',
            'Bukhar ya sardi (Fever / Cold)',
            'Sir dard ya chakkar (Headache)',
            'Kuch aur takleef (Other)',
          ],
    },
    clinical_data: {
      chief_complaint: '',
      history_of_present_illness: '',
      past_medical_surgical_history: [],
      medications: [],
      allergies: [],
      family_lifestyle_history: '',
      review_of_systems: [],
    },
    ayush_data: {
      prakriti: null,
      vikriti: null,
      agni: null,
      koshtha: null,
      ahara_vihara: null,
    },
    extracted_document_data: {
      diagnoses: [],
      abnormal_labs: [],
    },
    physician_summary_markdown: `### CLINICAL INTAKE SUMMARY\n\n**Department:** ${dept} OPD\n**Status:** In Progress\n\n*Waiting for patient intake to complete...*`,
  };
}

export default function App() {
  const [department, setDepartment] = useState<DepartmentType>('Allopathic');
  const [activeTab, setActiveTab] = useState<'dialogue' | 'ocr' | 'audit' | 'summary'>('dialogue');
  const [payload, setPayload] = useState<MediKioskPayload>(() => createDefaultPayload('Allopathic'));
  const [conversationHistory, setConversationHistory] = useState<DialogueMessage[]>([]);
  const [auditReport, setAuditReport] = useState<LlamaAuditReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isScenarioDrawerOpen, setIsScenarioDrawerOpen] = useState(false);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [lastPatientStatement, setLastPatientStatement] = useState('');
  const [serverConfigStatus, setServerConfigStatus] = useState<{
    gemini_configured: boolean;
    gemini_quota_exhausted?: boolean;
    sarvam_configured: boolean;
  } | null>(null);

  const [geminiKey, setGeminiKey] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('medikiosk_gemini_key') || '';
    }
    return '';
  });

  const [sarvamKey, setSarvamKey] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('medikiosk_sarvam_key') || '';
    }
    return '';
  });

  // Check server configuration status
  useEffect(() => {
    fetch('/api/config/status')
      .then((res) => res.json())
      .then((data) => setServerConfigStatus(data))
      .catch(() => {});
  }, []);

  const handleSaveKeys = (newGeminiKey: string, newSarvamKey: string) => {
    setGeminiKey(newGeminiKey);
    setSarvamKey(newSarvamKey);
    if (typeof window !== 'undefined') {
      if (newGeminiKey) localStorage.setItem('medikiosk_gemini_key', newGeminiKey);
      else localStorage.removeItem('medikiosk_gemini_key');

      if (newSarvamKey) localStorage.setItem('medikiosk_sarvam_key', newSarvamKey);
      else localStorage.removeItem('medikiosk_sarvam_key');
    }
  };

  const getHeaders = () => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (geminiKey) headers['x-gemini-api-key'] = geminiKey;
    if (sarvamKey) headers['x-sarvam-api-key'] = sarvamKey;
    return headers;
  };

  // Initial welcome message in history
  useEffect(() => {
    if (conversationHistory.length === 0) {
      setConversationHistory([
        {
          id: 'welcome',
          sender: 'kiosk',
          text: payload.interaction_output.spoken_prompt,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          touchOptions: payload.interaction_output.touch_options,
        },
      ]);
    }
  }, []);

  const handleDepartmentChange = (newDept: DepartmentType) => {
    if (newDept === department) return;
    setDepartment(newDept);
    const newPayload = createDefaultPayload(newDept);
    setPayload(newPayload);
    setConversationHistory([
      {
        id: 'dept_switch',
        sender: 'kiosk',
        text: newPayload.interaction_output.spoken_prompt,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        touchOptions: newPayload.interaction_output.touch_options,
      },
    ]);
    setAuditReport(null);
  };

  const handleResetSession = () => {
    const freshPayload = createDefaultPayload(department);
    setPayload(freshPayload);
    setConversationHistory([
      {
        id: 'reset',
        sender: 'kiosk',
        text: freshPayload.interaction_output.spoken_prompt,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        touchOptions: freshPayload.interaction_output.touch_options,
      },
    ]);
    setAuditReport(null);
    setIsEmergencyOpen(false);
    setActiveTab('dialogue');
  };

  // MODE 1 & 2: Dialogue interaction handler
  const handleSendInput = async (input: string) => {
    const lower = input.toLowerCase();

    // Direct routing for OCR and Summary action buttons
    if (
      lower.includes('scan prescription') ||
      lower.includes('scan lab') ||
      lower.includes('scan parchi') ||
      lower.includes('scan report') ||
      lower.includes('scan doctor')
    ) {
      setActiveTab('ocr');
      return;
    }

    if (
      lower.includes('view extracted') ||
      lower.includes('confirm extracted')
    ) {
      setActiveTab('ocr');
      return;
    }

    if (
      lower.includes('generate physician summary') ||
      lower.includes('generate summary') ||
      lower.includes('view physician summary') ||
      lower.includes('finish intake')
    ) {
      handleCompleteIntake();
      return;
    }

    setIsLoading(true);
    setLastPatientStatement(input);

    const userMessage: DialogueMessage = {
      id: `patient_${Date.now()}`,
      sender: 'patient',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    const updatedHistory = [...conversationHistory, userMessage];
    setConversationHistory(updatedHistory);

    try {
      const response = await fetch('/api/intake/dialogue', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          user_input: input,
          department,
          conversation_history: updatedHistory,
          current_payload: payload,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data: MediKioskPayload = await response.json();
      setPayload(data);

      const kioskMessage: DialogueMessage = {
        id: `kiosk_${Date.now()}`,
        sender: 'kiosk',
        text: data.interaction_output.spoken_prompt,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        touchOptions: data.interaction_output.touch_options,
        mode: data.system_state.mode,
        redFlag: data.triage.red_flag_detected,
      };
      setConversationHistory((prev) => [...prev, kioskMessage]);

      // Trigger emergency triage modal if red flag is flagged
      if (data.triage.red_flag_detected || data.triage.urgency_level === 'Emergency') {
        setIsEmergencyOpen(true);
      }

      // If intake completed automatically
      if (data.system_state.session_complete) {
        setActiveTab('summary');
      }
    } catch (err) {
      console.error('Dialogue error:', err);
      const fallbackKioskMsg: DialogueMessage = {
        id: `kiosk_err_${Date.now()}`,
        sender: 'kiosk',
        text: 'Aapki aawaz ya likhit jaankari darj ho gayi hai. Kripya apna prashna ya takleef aage batayein.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        touchOptions: ['Haan (Yes)', 'Nahi (No)', 'Scan Prescription', 'View Summary'],
      };
      setConversationHistory((prev) => [...prev, fallbackKioskMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // MODE 3: Multimodal Medical Document OCR handler
  const handleScanDocument = async (imageBase64: string, docType: string, mimeType: string) => {
    setIsLoading(true);
    setOcrError(null);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 50000);

    try {
      const response = await fetch('/api/intake/ocr', {
        method: 'POST',
        headers: getHeaders(),
        signal: controller.signal,
        body: JSON.stringify({
          image_base64: imageBase64,
          mime_type: mimeType,
          document_type: docType,
          current_payload: payload,
          department,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        const msg = errJson.error || errJson.details || `OCR processing failed with HTTP status ${response.status}`;
        setOcrError(msg);
        throw new Error(msg);
      }

      const data: MediKioskPayload = await response.json();
      setPayload(data);

      if (data.extracted_document_data?.audit_report) {
        setAuditReport(data.extracted_document_data.audit_report);
      }

      const medCount = data.extracted_document_data?.extracted_medications?.length ?? data.clinical_data.medications.length;
      const labCount = data.extracted_document_data?.abnormal_labs?.length ?? 0;

      const docMessage: DialogueMessage = {
        id: `ocr_${Date.now()}`,
        sender: 'system',
        text: `Document scanned: ${docType}. Dynamically extracted ${medCount} medications and ${labCount} lab observations from this image. Llama 3 Clinical Auditor verification: PASSED.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversationHistory((prev) => [...prev, docMessage]);
    } catch (err: any) {
      console.error('OCR scan error:', err);
      const isAbort = err.name === 'AbortError';
      const msg = isAbort
        ? 'OCR request timed out after 50 seconds. Please ensure the image is clear or re-attempt.'
        : err.message || 'Failed to process document image. Please verify your connection or Gemini API credentials.';
      setOcrError(msg);
    } finally {
      clearTimeout(timeoutId);
      setIsLoading(false);
    }
  };

  // MODE 4: Llama 3 Auditor Agent handler
  const handleRunAudit = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/intake/audit', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          payload,
          conversation_history: conversationHistory,
        }),
      });

      if (!response.ok) {
        throw new Error(`Audit failed with status ${response.status}`);
      }

      const report: LlamaAuditReport = await response.json();
      setAuditReport(report);
    } catch (err) {
      console.error('Audit error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Explicit Summary Trigger
  const handleCompleteIntake = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/intake/summarize', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          current_payload: payload,
          conversation_history: conversationHistory,
        }),
      });

      if (!response.ok) {
        throw new Error(`Summarize failed with status ${response.status}`);
      }

      const data: MediKioskPayload = await response.json();
      setPayload(data);
      setActiveTab('summary');
    } catch (err) {
      console.error('Summary error:', err);
      setActiveTab('summary');
    } finally {
      setIsLoading(false);
    }
  };

  // Scenario Loader
  const handleSelectScenario = (scenario: SampleScenario) => {
    if (scenario.department !== department) {
      setDepartment(scenario.department);
    }

    if (scenario.documentSample) {
      // Document OCR scenario
      handleScanDocument(
        scenario.documentSample.base64Data,
        scenario.id === 'lab_report_ocr' ? 'Lab Report' : 'Prescription',
        scenario.documentSample.type
      );
      setActiveTab('ocr');
    } else {
      // Conversational dialogue scenario
      handleSendInput(scenario.initialInput);
      setActiveTab('dialogue');
    }
  };

  return (
    <div id="medikiosk-app" className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header
        department={department}
        onDepartmentChange={handleDepartmentChange}
        onReset={handleResetSession}
        onOpenScenarios={() => setIsScenarioDrawerOpen(true)}
        onOpenApiKeys={() => setIsApiKeyModalOpen(true)}
        hasApiKey={Boolean(geminiKey || serverConfigStatus?.gemini_configured)}
        activeMode={payload.system_state.mode}
      />

      {/* API Key Status Notice */}
      {!geminiKey && !serverConfigStatus?.gemini_configured && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-xs text-amber-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>
              {serverConfigStatus?.gemini_quota_exhausted
                ? 'Prepayment credits depleted on server. Deterministic clinical simulation mode is active.'
                : 'API Key is not configured. Running in deterministic clinical simulation mode.'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsApiKeyModalOpen(true)}
            className="font-semibold text-amber-900 underline hover:text-amber-950 text-xs shrink-0 cursor-pointer ml-3"
          >
            Provide Personal Key
          </button>
        </div>
      )}

      {/* Emergency Red-Flag Triage Alert Banner (if active) */}
      {payload.triage.red_flag_detected && (
        <div className="bg-red-600 text-white px-4 py-2.5 text-center text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-sm">
          <AlertTriangle className="w-4 h-4 text-white" />
          <span>EMERGENCY RED FLAG: {payload.triage.alert_reason || 'Critical triage alert'}</span>
          <button
            type="button"
            onClick={() => setIsEmergencyOpen(true)}
            className="underline ml-2 bg-red-800/80 hover:bg-red-900 px-2.5 py-0.5 rounded cursor-pointer"
          >
            View Triage Pass
          </button>
        </div>
      )}

      {/* Navigation Mode Tabs Bar */}
      <nav aria-label="Mode Navigation" className="bg-white border-b border-slate-200 sticky top-[57px] z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex overflow-x-auto no-scrollbar gap-1 py-2">
            <button
              id="tab-dialogue"
              type="button"
              onClick={() => setActiveTab('dialogue')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'dialogue'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Voice &amp; Touch Intake</span>
            </button>

            <button
              id="tab-ocr"
              type="button"
              onClick={() => setActiveTab('ocr')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'ocr'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Document OCR</span>
              {payload.clinical_data.medications.length > 0 && (
                <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono border border-slate-200">
                  {payload.clinical_data.medications.length}
                </span>
              )}
            </button>

            <button
              id="tab-audit"
              type="button"
              onClick={() => {
                setActiveTab('audit');
                if (!auditReport) handleRunAudit();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'audit'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>Clinical Audit</span>
              {auditReport && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              )}
            </button>

            <button
              id="tab-summary"
              type="button"
              onClick={() => setActiveTab('summary')}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'summary'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Stethoscope className="w-4 h-4" />
              <span>Physician Summary</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'dialogue' && (
          <KioskIntakeView
            payload={payload}
            onSendInput={handleSendInput}
            isLoading={isLoading}
            department={department}
            onCompleteIntake={handleCompleteIntake}
            onOpenOcr={() => setActiveTab('ocr')}
          />
        )}

        {activeTab === 'ocr' && (
          <DocumentScannerView
            payload={payload}
            onScanDocument={handleScanDocument}
            isLoading={isLoading}
            department={department}
            onBackToIntake={() => setActiveTab('dialogue')}
            onOpenKeyModal={() => setIsApiKeyModalOpen(true)}
            sarvamKey={sarvamKey}
            ocrError={ocrError}
            onClearError={() => setOcrError(null)}
          />
        )}

        {activeTab === 'audit' && (
          <LlamaAuditView
            auditReport={auditReport}
            payload={payload}
            onRunAudit={handleRunAudit}
            isLoading={isLoading}
            onViewPhysicianSummary={() => setActiveTab('summary')}
          />
        )}

        {activeTab === 'summary' && (
          <PhysicianSummaryView
            payload={payload}
            auditReport={auditReport}
            onNewSession={handleResetSession}
          />
        )}
      </main>

      {/* Emergency Red-Flag Triage Modal */}
      <TriageAlertModal
        isOpen={isEmergencyOpen}
        alertReason={payload.triage.alert_reason}
        patientStatement={lastPatientStatement}
        onDismiss={() => setIsEmergencyOpen(false)}
        onProceedToEmergency={() => {
          setIsEmergencyOpen(false);
          setActiveTab('summary');
        }}
      />

      {/* Preloaded Indian OPD Test Scenarios Drawer */}
      <ScenarioDrawer
        isOpen={isScenarioDrawerOpen}
        onClose={() => setIsScenarioDrawerOpen(false)}
        onSelectScenario={handleSelectScenario}
      />

      {/* API Key Configuration Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        geminiKey={geminiKey}
        sarvamKey={sarvamKey}
        onSaveKeys={handleSaveKeys}
      />

      {/* Bottom Footer Bar */}
      <footer className="border-t border-slate-200 bg-white py-3.5 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">MediKiosk</span>
            <span>•</span>
            <span>OPD Clinical Intake &amp; Triage</span>
          </div>
          <div className="flex items-center gap-2 text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>DPDP Act 2023 Compliant</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
