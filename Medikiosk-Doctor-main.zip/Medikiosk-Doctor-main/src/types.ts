export type OperationalMode = 'Dialogue' | 'OCR' | 'Summary' | 'Emergency Alert';
export type DepartmentType = 'Allopathic' | 'AYUSH';
export type UrgencyLevel = 'Routine' | 'Urgent' | 'Emergency';

export interface Medication {
  drug_name: string;
  dosage: string;
  frequency: string;
  duration?: string;
}

export interface AbnormalLab {
  test: string;
  value: string;
  reference: string;
  status: 'High' | 'Low' | 'Critical';
}

export interface ClinicalData {
  chief_complaint: string;
  history_of_present_illness: string;
  past_medical_surgical_history: string[];
  medications: Medication[];
  allergies: string[];
  family_lifestyle_history: string;
  review_of_systems: string[];
}

export interface AyushData {
  prakriti: string | null;
  vikriti: string | null;
  agni: string | null;
  koshtha: string | null;
  ahara_vihara: string | null;
  satmya?: string | null;
  sattva?: string | null;
  vaya?: string | null;
}

export interface ExtractedDocumentData {
  diagnoses: string[];
  abnormal_labs: AbnormalLab[];
  extracted_medications?: Medication[];
  audit_report?: LlamaAuditReport;
  raw_text?: string;
  document_name?: string;
  chronological_encounters?: Array<{
    date: string;
    facility?: string;
    summary: string;
  }>;
}

export interface MediKioskPayload {
  system_state: {
    mode: OperationalMode;
    department: DepartmentType;
    session_complete: boolean;
  };
  triage: {
    red_flag_detected: boolean;
    urgency_level: UrgencyLevel;
    alert_reason: string | null;
  };
  interaction_output: {
    spoken_prompt: string;
    touch_options: string[];
  };
  clinical_data: ClinicalData;
  ayush_data: AyushData;
  extracted_document_data: ExtractedDocumentData;
  physician_summary_markdown: string;
}

export interface DialogueMessage {
  id: string;
  sender: 'kiosk' | 'patient' | 'system';
  text: string;
  timestamp: string;
  audioPrompt?: string;
  touchOptions?: string[];
  mode?: OperationalMode;
  redFlag?: boolean;
}

export interface LlamaAuditReport {
  timestamp: string;
  auditor_agent: string;
  verification_status: 'VERIFIED_PASSED' | 'FLAGGED_ATTENTION' | 'CRITICAL_DISCREPANCY';
  confidence_score: number;
  checks: {
    socrates_adherence: { passed: boolean; details: string };
    red_flag_sensitivity: { passed: boolean; details: string };
    anti_hallucination: { passed: boolean; details: string };
    dpdp_compliance: { passed: boolean; details: string };
    fhir_data_integrity: { passed: boolean; details: string };
  };
  discrepancies: string[];
  clinical_notes_for_doctor: string[];
}
