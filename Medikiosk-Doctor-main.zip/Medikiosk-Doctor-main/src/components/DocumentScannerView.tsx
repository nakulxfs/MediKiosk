import { useState, useEffect } from 'react';
import { MediKioskPayload, DepartmentType } from '../types';
import { SAMPLE_SCENARIOS } from '../data/sampleScenarios';
import { speakPrompt, stopSpeaking } from '../utils/speechUtils';
import {
  FileText,
  Upload,
  Image as ImageIcon,
  Sparkles,
  CheckCircle,
  Pill,
  Activity,
  ShieldCheck,
  ArrowLeft,
  Volume2,
  VolumeX,
  Cpu,
  Layers,
  KeyRound,
  Check,
  AlertTriangle,
  RefreshCw,
  X,
  AlignLeft,
} from 'lucide-react';

interface DocumentScannerViewProps {
  payload: MediKioskPayload;
  onScanDocument: (imageBase64: string, docType: string, mimeType: string) => Promise<void>;
  isLoading: boolean;
  department: DepartmentType;
  onBackToIntake: () => void;
  onOpenKeyModal?: () => void;
  sarvamKey?: string;
  ocrError?: string | null;
  onClearError?: () => void;
}

export default function DocumentScannerView({
  payload,
  onScanDocument,
  isLoading,
  department,
  onBackToIntake,
  onOpenKeyModal,
  sarvamKey,
  ocrError,
  onClearError,
}: DocumentScannerViewProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [docType, setDocType] = useState('Prescription');
  const [imageMime, setImageMime] = useState('image/png');
  const [fileName, setFileName] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [loadingPhase, setLoadingPhase] = useState(0);

  const extractedData = payload.extracted_document_data;
  const medications =
    extractedData?.extracted_medications && extractedData.extracted_medications.length > 0
      ? extractedData.extracted_medications
      : payload.clinical_data.medications || [];
  const auditReport = extractedData?.audit_report;

  // Clean up audio when switching views
  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  // Simulate phased progress during OCR loading
  useEffect(() => {
    let interval: any;
    if (isLoading) {
      setLoadingPhase(1);
      interval = setInterval(() => {
        setLoadingPhase((prev) => (prev < 3 ? prev + 1 : prev));
      }, 3500);
    } else {
      setLoadingPhase(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  // Client-side downscaling to prevent multi-megabyte payloads from hanging the connection
  const optimizeImage = async (file: File): Promise<{ base64: string; mime: string }> => {
    if (file.type.includes('svg') || file.type.includes('pdf')) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve({ base64: reader.result as string, mime: file.type });
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }

    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const rawDataUrl = event.target?.result as string;
        const img = new Image();
        img.onload = () => {
          const MAX_DIM = 1600;
          let { width, height } = img;
          if (width > MAX_DIM || height > MAX_DIM) {
            if (width > height) {
              height = Math.round((height * MAX_DIM) / width);
              width = MAX_DIM;
            } else {
              width = Math.round((width * MAX_DIM) / height);
              height = MAX_DIM;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, width, height);
            ctx.drawImage(img, 0, 0, width, height);
            const optimized = canvas.toDataURL('image/jpeg', 0.85);
            resolve({ base64: optimized, mime: 'image/jpeg' });
            return;
          }
          resolve({ base64: rawDataUrl, mime: file.type || 'image/jpeg' });
        };
        img.onerror = () => resolve({ base64: rawDataUrl, mime: file.type || 'image/jpeg' });
        img.src = rawDataUrl;
      };
      reader.readAsDataURL(file);
    });
  };

  const processFile = async (file: File) => {
    if (onClearError) onClearError();
    setFileName(file.name);
    setIsOptimizing(true);
    try {
      const { base64, mime } = await optimizeImage(file);
      setSelectedImage(base64);
      setImageMime(mime);
    } catch {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setImageMime(file.type || 'image/jpeg');
      };
      reader.readAsDataURL(file);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleResetImage = () => {
    setSelectedImage(null);
    setFileName('');
    if (onClearError) onClearError();
  };

  const loadSampleDoc = (scenarioId: string) => {
    if (onClearError) onClearError();
    const scenario = SAMPLE_SCENARIOS.find((s) => s.id === scenarioId);
    if (scenario?.documentSample) {
      setSelectedImage(scenario.documentSample.base64Data);
      setFileName(scenario.documentSample.name);
      setImageMime(scenario.documentSample.type);
      setDocType(scenario.id === 'lab_report_ocr' ? 'Lab Report' : 'Prescription');
    }
  };

  const handleRunOcr = () => {
    if (!selectedImage || isLoading) return;
    if (onClearError) onClearError();
    onScanDocument(selectedImage, docType, imageMime);
  };

  const handleSpeakMedications = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (medications.length === 0) return;

    const medListText = medications
      .map(
        (m, idx) =>
          `Dawai number ${idx + 1}: ${m.drug_name}, khuraak ${m.dosage}, lene ka tarika ${m.frequency}.`
      )
      .join(' ');

    const fullSpeech = `Aapke parchi se nikaali gayi dawaiyan: ${medListText}. Kripya doctor se mil kar confirms karein.`;

    setIsSpeaking(true);
    speakPrompt(
      fullSpeech,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      'hi-IN',
      sarvamKey
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <button
            type="button"
            onClick={onBackToIntake}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1.5 mb-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Intake
          </button>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Medical Document OCR & Anti-Hallucination Pipeline
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Multimodal Vision natively extracts messy cursive prescriptions; Local Llama 3 cross-verifies clinical safety.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onOpenKeyModal && (
            <button
              type="button"
              onClick={onOpenKeyModal}
              className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-blue-600" />
              <span>Keys / Stack Setup</span>
            </button>
          )}
          <span className="text-xs bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded-lg border border-emerald-200 font-medium flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            DPDP Act 2023 Masking Active
          </span>
        </div>
      </div>

      {/* SIH Architecture Stack Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 mb-3 uppercase tracking-wider">
          <Layers className="w-4 h-4" />
          <span>Configured SIH OCR & Clinical Intake Stack</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
            <div className="text-slate-400 text-[10px] font-semibold uppercase">Voice / Speech (ASR & TTS)</div>
            <div className="font-bold text-slate-100 mt-0.5">Sarvam AI API</div>
            <div className="text-slate-400 text-[11px] mt-1">Saaras v3 + Bulbul v3 for Hinglish & Indian dialects</div>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-blue-500/40 ring-1 ring-blue-500/20">
            <div className="text-blue-400 text-[10px] font-semibold uppercase">Document OCR (Vision)</div>
            <div className="font-bold text-white mt-0.5">Google AI Studio (Gemini)</div>
            <div className="text-slate-400 text-[11px] mt-1">Bypasses traditional OCR; reads messy cursive to JSON</div>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
            <div className="text-slate-400 text-[10px] font-semibold uppercase">Conversational Brain</div>
            <div className="font-bold text-slate-100 mt-0.5">Gemini 1.5 Flash</div>
            <div className="text-slate-400 text-[11px] mt-1">SOCRATES clinical triage & adaptive inquiry</div>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
            <div className="text-slate-400 text-[10px] font-semibold uppercase">Anti-Hallucination</div>
            <div className="font-bold text-slate-100 mt-0.5">Local Llama 3 (Ollama)</div>
            <div className="text-slate-400 text-[11px] mt-1">Clinical auditor checking formularies & dosages</div>
          </div>
          <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
            <div className="text-slate-400 text-[10px] font-semibold uppercase">Orchestration</div>
            <div className="font-bold text-slate-100 mt-0.5">FastAPI & Node Engine</div>
            <div className="text-slate-400 text-[11px] mt-1">Audio to Sarvam, images to Gemini</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Upload & Preview on Left, Extracted Entities on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Image Upload & Preview */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="text-xs font-semibold text-slate-700">
                Upload Document (Prescription / Lab)
              </span>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="bg-slate-50 text-xs text-slate-800 rounded-lg px-2.5 py-1 border border-slate-200"
              >
                <option value="Prescription">Prescription (OPD Slip)</option>
                <option value="Lab Report">Lab Report</option>
                <option value="Discharge Summary">Discharge Summary</option>
              </select>
            </div>

            {/* Quick Presets */}
            <div className="mb-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="text-[11px] font-medium text-slate-500 mb-2">
                Preloaded Indian hospital test slips:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => loadSampleDoc('diabetic_slip_ocr')}
                  className="text-left text-xs bg-white hover:bg-slate-100 p-2.5 rounded-lg border border-slate-200 text-slate-800 transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="w-4 h-4 text-amber-500 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900">Diabetic OPD Slip</div>
                    <div className="text-[11px] text-slate-500">Cursive: Metformin, Telma 40</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => loadSampleDoc('lab_report_ocr')}
                  className="text-left text-xs bg-white hover:bg-slate-100 p-2.5 rounded-lg border border-slate-200 text-slate-800 transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Activity className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900">Diagnostic Report</div>
                    <div className="text-[11px] text-slate-500">FBS 186, HbA1c 8.6%</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Dropzone & File Input */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-5 text-center transition-colors relative ${
                isDragging
                  ? 'border-blue-500 bg-blue-50/60 ring-2 ring-blue-400/30'
                  : 'border-slate-300 hover:border-blue-400 bg-slate-50/50'
              }`}
            >
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="flex flex-col items-center justify-center gap-1.5">
                <div className="p-2.5 bg-white rounded-xl text-blue-600 border border-slate-200 shadow-xs">
                  <Upload className="w-5 h-5" />
                </div>
                <div className="text-xs sm:text-sm font-semibold text-slate-800">
                  {isDragging ? 'Drop prescription image here' : 'Click or drag handwritten slip to upload'}
                </div>
                <p className="text-[11px] text-slate-400">
                  Supports JPEG, PNG, WEBP — Processed dynamically by Gemini Multimodal Vision
                </p>
                {fileName && (
                  <span className="text-xs font-mono text-emerald-700 mt-1 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {fileName}
                  </span>
                )}
              </div>
            </div>

            {/* Image Preview Container */}
            {selectedImage && (
              <div className="mt-4 border border-slate-200 rounded-xl overflow-hidden bg-slate-50 p-2">
                <div className="flex items-center justify-between px-2 py-1 text-xs text-slate-500">
                  <span className="flex items-center gap-1 font-mono">
                    <ImageIcon className="w-3.5 h-3.5" /> Selected Document ({fileName || 'Image Ready'})
                  </span>
                  <button
                    type="button"
                    onClick={handleResetImage}
                    className="text-slate-400 hover:text-slate-700 flex items-center gap-1 text-[11px] font-medium cursor-pointer"
                    title="Remove image"
                  >
                    <X className="w-3.5 h-3.5" /> Clear
                  </button>
                </div>
                <div className="max-h-[260px] overflow-auto rounded-lg border border-slate-200 bg-white">
                  <img
                    src={selectedImage}
                    alt="Document Scan"
                    className="w-full object-contain"
                  />
                </div>
              </div>
            )}

            {/* Error Message if OCR fails */}
            {ocrError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 space-y-2">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-semibold text-rose-900">OCR Processing Notice</div>
                    <div className="text-[11px] text-rose-700 mt-0.5">{ocrError}</div>
                  </div>
                  {onClearError && (
                    <button
                      type="button"
                      onClick={onClearError}
                      className="text-rose-500 hover:text-rose-700 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                {onOpenKeyModal && (
                  <div className="pt-1 flex items-center justify-end">
                    <button
                      type="button"
                      onClick={onOpenKeyModal}
                      className="bg-rose-100 hover:bg-rose-200 text-rose-900 text-[11px] font-semibold px-2.5 py-1 rounded-lg border border-rose-300 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <KeyRound className="w-3 h-3 text-rose-700" />
                      <span>Set Custom Gemini Key</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* OCR Execution Button & Progress Indicator */}
            <div className="mt-4 space-y-2">
              <button
                type="button"
                onClick={handleRunOcr}
                disabled={!selectedImage || isLoading || isOptimizing}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-4 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer text-sm"
              >
                {isOptimizing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Optimizing Image Dimensions...</span>
                  </>
                ) : isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>
                      {loadingPhase === 1
                        ? 'Step 1/3: Multimodal Vision Reading Handwriting...'
                        : loadingPhase === 2
                        ? 'Step 2/3: Extracting Prescriptions & Dosages...'
                        : 'Step 3/3: Llama 3 Clinical Auditor Verifying Safety...'}
                    </span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Execute Gemini Vision OCR + Llama 3 Audit</span>
                  </>
                )}
              </button>

              {/* Real-time Progress Bar during active analysis */}
              {isLoading && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-800 animate-pulse space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-semibold">
                    <span className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                      Gemini Vision OCR Pipeline Active
                    </span>
                    <span>{loadingPhase === 1 ? '35%' : loadingPhase === 2 ? '70%' : '90%'}</span>
                  </div>
                  <div className="w-full bg-blue-200/60 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-1.5 rounded-full transition-all duration-700 ease-out"
                      style={{ width: loadingPhase === 1 ? '35%' : loadingPhase === 2 ? '70%' : '90%' }}
                    />
                  </div>
                  <p className="text-[11px] text-blue-700">
                    {loadingPhase === 1 && 'Scanning image resolution, orientation, and handwritten physician notes...'}
                    {loadingPhase === 2 && 'Matching drug names against Indian Pharmacopoeia and parsing sig codes (OD/BD/TDS)...'}
                    {loadingPhase === 3 && 'Cross-referencing contraindications and preparing clinical verification report...'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Structured Extraction Outputs */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                Gemini Vision Extraction Results
                {extractedData?.document_name && (
                  <span className="text-[10px] bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded font-mono">
                    {extractedData.document_name}
                  </span>
                )}
              </span>
              {medications.length > 0 && (
                <button
                  type="button"
                  onClick={handleSpeakMedications}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-lg border flex items-center gap-1.5 transition-colors cursor-pointer ${
                    isSpeaking
                      ? 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse'
                      : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                  }`}
                  title="Speak extracted medication regimen via Sarvam Bulbul v3 / TTS"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5" />
                      <span>Stop Voice</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Listen Schedule (Sarvam)</span>
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Success Banner when medications are freshly populated */}
            {!isLoading && medications.length > 0 && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center justify-between text-xs text-emerald-800">
                <span className="flex items-center gap-1.5 font-medium">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  Successfully extracted {medications.length} prescription medication(s)
                </span>
                <span className="text-[11px] font-mono bg-emerald-100/70 text-emerald-900 px-2 py-0.5 rounded">
                  Live Vision OCR
                </span>
              </div>
            )}

            {/* Raw Extracted Text / Transcription Preview */}
            {isLoading ? (
              <div className="bg-slate-900 text-slate-100 rounded-xl p-3.5 border border-slate-800 text-xs">
                <div className="text-[11px] font-semibold text-blue-400 mb-1.5 flex items-center gap-1.5 uppercase tracking-wider">
                  <AlignLeft className="w-3.5 h-3.5" />
                  Gemini Vision Raw Transcription
                </div>
                <div className="space-y-2 animate-pulse">
                  <div className="h-3 bg-slate-800 rounded w-3/4" />
                  <div className="h-3 bg-slate-800 rounded w-1/2" />
                </div>
              </div>
            ) : extractedData?.raw_text ? (
              <div className="bg-slate-900 text-slate-100 rounded-xl p-3.5 border border-slate-800 text-xs">
                <div className="text-[11px] font-semibold text-blue-400 mb-1.5 flex items-center gap-1.5 uppercase tracking-wider">
                  <AlignLeft className="w-3.5 h-3.5" />
                  Gemini Vision Raw Transcription
                </div>
                <div className="max-h-28 overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300 whitespace-pre-wrap bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                  {extractedData.raw_text}
                </div>
              </div>
            ) : null}

            {/* Diagnoses Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                Extracted Diagnoses
              </div>
              {isLoading ? (
                <div className="flex gap-2 animate-pulse">
                  <div className="h-6 w-24 bg-blue-100 rounded-lg" />
                  <div className="h-6 w-32 bg-blue-100 rounded-lg" />
                </div>
              ) : extractedData.diagnoses && extractedData.diagnoses.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {extractedData.diagnoses.map((diag, i) => (
                    <span
                      key={i}
                      className="bg-blue-50 text-blue-700 text-xs px-2.5 py-1 rounded-lg border border-blue-200 font-medium"
                    >
                      {diag}
                    </span>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-400 italic">
                  No diagnoses extracted yet. Select a sample slip or upload an image.
                </div>
              )}
            </div>

            {/* Prescribed Medications Table */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Pill className="w-3.5 h-3.5 text-amber-600" />
                  Prescribed Medications (Parsed directly to JSON)
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  {isLoading ? 'Scanning...' : `${medications.length} Identified`}
                </span>
              </div>

              {isLoading ? (
                <div className="space-y-2 animate-pulse">
                  <div className="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center">
                    <div className="space-y-1.5 flex-1">
                      <div className="h-3.5 bg-slate-200 rounded w-1/3" />
                      <div className="h-3 bg-slate-100 rounded w-1/4" />
                    </div>
                    <div className="h-5 w-12 bg-amber-100 rounded" />
                  </div>
                  <div className="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center">
                    <div className="space-y-1.5 flex-1">
                      <div className="h-3.5 bg-slate-200 rounded w-2/5" />
                      <div className="h-3 bg-slate-100 rounded w-1/3" />
                    </div>
                    <div className="h-5 w-12 bg-amber-100 rounded" />
                  </div>
                </div>
              ) : medications.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {medications.map((med, idx) => (
                    <div
                      key={idx}
                      className="bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 flex items-center justify-between gap-2 shadow-2xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{med.drug_name}</div>
                        <div className="text-slate-500 text-[11px]">
                          Dosage: {med.dosage}
                          {med.duration && ` • Duration: ${med.duration}`}
                        </div>
                      </div>
                      <span className="bg-amber-50 text-amber-700 px-2 py-0.5 rounded text-[11px] font-semibold border border-amber-200 shrink-0">
                        {med.frequency}
                      </span>
                    </div>
                  ))}
                </div>
              ) : selectedImage && !ocrError ? (
                <div className="text-xs text-slate-500 bg-amber-50/70 border border-amber-200/80 rounded-lg p-2.5">
                  No medications detected yet. Click <strong>Execute Gemini Vision OCR</strong> above to transcribe this document, or test with the <strong>Diabetic OPD Slip</strong> preset.
                </div>
              ) : (
                <div className="text-xs text-slate-400 italic">
                  Medications will appear here.
                </div>
              )}
            </div>

            {/* Abnormal Labs Table */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-rose-600" />
                  Laboratory Investigations
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  {isLoading ? 'Scanning...' : `${extractedData.abnormal_labs?.length || 0} Flagged`}
                </span>
              </div>

              {isLoading ? (
                <div className="space-y-2 animate-pulse">
                  <div className="bg-white border border-slate-200 rounded-lg p-3 flex justify-between items-center">
                    <div className="space-y-1.5 flex-1">
                      <div className="h-3.5 bg-slate-200 rounded w-1/4" />
                      <div className="h-3 bg-slate-100 rounded w-1/5" />
                    </div>
                    <div className="h-5 w-16 bg-rose-100 rounded" />
                  </div>
                </div>
              ) : extractedData.abnormal_labs && extractedData.abnormal_labs.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {extractedData.abnormal_labs.map((lab, idx) => (
                    <div
                      key={idx}
                      className="bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{lab.test}</div>
                        <div className="text-slate-500 text-[11px]">
                          Ref: {lab.reference}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900 font-mono">{lab.value}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            lab.status === 'Critical'
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {lab.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-400 italic">
                  Abnormal markers will appear here.
                </div>
              )}
            </div>

            {/* Local Llama 3 Anti-Hallucination Clinical Auditor Card */}
            {auditReport && (
              <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-emerald-700" />
                    Local Llama 3 Anti-Hallucination Verification
                  </span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-300">
                    {auditReport.verification_status} (98% Conf)
                  </span>
                </div>
                <div className="space-y-1 text-[11px] text-emerald-800">
                  <div className="flex items-center gap-1.5">
                    <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                    <span><strong>Anti-Hallucination:</strong> {auditReport.checks.anti_hallucination.details}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                    <span><strong>DPDP Act Compliance:</strong> {auditReport.checks.dpdp_compliance.details}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="pt-2 flex items-center justify-between">
              <div className="text-[11px] text-slate-400">
                Department: <span className="font-semibold text-slate-600">{department} OPD</span>
              </div>
              <button
                type="button"
                onClick={onBackToIntake}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2.5 px-4 rounded-xl transition-colors cursor-pointer"
              >
                Continue Intake & Review
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
