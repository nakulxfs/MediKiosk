import { useState } from 'react';
import Markdown from 'react-markdown';
import { MediKioskPayload, LlamaAuditReport } from '../types';
import {
  FileText,
  Code2,
  Copy,
  Check,
  Printer,
  ShieldCheck,
  Stethoscope,
  Send,
} from 'lucide-react';

interface PhysicianSummaryViewProps {
  payload: MediKioskPayload;
  auditReport: LlamaAuditReport | null;
  onNewSession: () => void;
}

export default function PhysicianSummaryView({
  payload,
  auditReport,
  onNewSession,
}: PhysicianSummaryViewProps) {
  const [activeTab, setActiveTab] = useState<'markdown' | 'json' | 'fhir'>('markdown');
  const [copied, setCopied] = useState(false);
  const [dispatched, setDispatched] = useState(false);

  const jsonString = JSON.stringify(payload, null, 2);

  // Synthesize standard FHIR R4 Bundle preview
  const fhirBundle = {
    resourceType: 'Bundle',
    type: 'document',
    timestamp: new Date().toISOString(),
    entry: [
      {
        resource: {
          resourceType: 'Composition',
          status: 'final',
          type: { text: 'Hospital OPD Clinical Intake Summary' },
          subject: { reference: 'Patient/[ABHA Omitted]', display: 'OPD Attendee' },
          date: new Date().toISOString(),
          title: 'MediKiosk Clinical Triage Summary',
        },
      },
      {
        resource: {
          resourceType: 'Condition',
          clinicalStatus: { coding: [{ code: 'active' }] },
          code: { text: payload.clinical_data.chief_complaint || 'General OPD evaluation' },
          note: [{ text: payload.clinical_data.history_of_present_illness }],
        },
      },
      ...(payload.clinical_data.medications || []).map((med) => ({
        resource: {
          resourceType: 'MedicationStatement',
          status: 'active',
          medicationCodeableConcept: { text: med.drug_name },
          dosage: [{ text: `${med.dosage} - ${med.frequency}` }],
        },
      })),
      ...(payload.extracted_document_data?.abnormal_labs || []).map((lab) => ({
        resource: {
          resourceType: 'Observation',
          status: 'final',
          code: { text: lab.test },
          valueString: lab.value,
          interpretation: [{ text: lab.status }],
        },
      })),
    ],
  };

  const handleCopy = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(jsonString);
      } else {
        throw new Error('Clipboard API unavailable');
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = jsonString;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (fallbackErr) {
        console.warn('Fallback copy error:', fallbackErr);
      }
    }
  };

  const handlePrint = () => {
    try {
      window.print();
    } catch (err) {
      console.warn('Window print not permitted in iframe sandbox:', err);
    }
  };

  const handleSendToDoctor = () => {
    setDispatched(true);
    setTimeout(() => setDispatched(false), 3000);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner with Triage Urgency */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
              <Stethoscope className="w-3.5 h-3.5" /> OPD Summary
            </span>
            <span
              className={`text-xs px-2 py-0.5 rounded font-semibold uppercase border ${
                payload.triage.urgency_level === 'Emergency'
                  ? 'bg-red-50 text-red-700 border-red-200'
                  : payload.triage.urgency_level === 'Urgent'
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}
            >
              Triage: {payload.triage.urgency_level}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
            Physician Summary
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Structured clinical report ready for review and EMR export.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold py-2 px-3 rounded-xl border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy JSON'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold py-2 px-3 rounded-xl border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>

          <button
            type="button"
            onClick={handleSendToDoctor}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 px-3.5 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{dispatched ? 'Sent!' : 'Send to Physician'}</span>
          </button>
        </div>
      </div>

      {/* View Switcher Tabs */}
      <div className="flex border-b border-slate-200 gap-2">
        <button
          type="button"
          onClick={() => setActiveTab('markdown')}
          className={`pb-2.5 px-3.5 text-xs font-semibold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer ${
            activeTab === 'markdown'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          Clinical Note
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('json')}
          className={`pb-2.5 px-3.5 text-xs font-semibold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer ${
            activeTab === 'json'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          JSON Payload
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fhir')}
          className={`pb-2.5 px-3.5 text-xs font-semibold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer ${
            activeTab === 'fhir'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          FHIR R4 Bundle
        </button>
      </div>

      {/* Tab 1: Formatted Physician Markdown Note */}
      {activeTab === 'markdown' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs text-slate-500">
            <div>
              <span>Patient: Anonymous OPD Attendee</span>
              <span className="mx-2">•</span>
              <span className="text-emerald-600 font-medium">Aadhaar Redacted</span>
            </div>
            {auditReport && (
              <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono text-[11px]">
                Audit: {auditReport.verification_status}
              </span>
            )}
          </div>

          <div className="prose prose-slate max-w-none text-slate-800 text-sm leading-relaxed prose-headings:text-slate-900 prose-headings:font-bold prose-p:my-2 prose-li:my-0.5">
            <Markdown>{payload.physician_summary_markdown || '*No clinical summary generated yet.*'}</Markdown>
          </div>
        </div>
      )}

      {/* Tab 2: Strict JSON Output */}
      {activeTab === 'json' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs text-slate-500">
            <span className="font-semibold text-slate-700">JSON Schema Output</span>
            <span className="font-mono text-[11px] text-emerald-600">Schema Validated</span>
          </div>
          <pre className="text-xs text-slate-800 font-mono overflow-x-auto p-4 bg-slate-50 rounded-xl max-h-[500px] leading-relaxed border border-slate-200">
            {jsonString}
          </pre>
        </div>
      )}

      {/* Tab 3: ABDM FHIR R4 Bundle */}
      {activeTab === 'fhir' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-xs text-slate-500">
            <span className="font-semibold text-slate-700">FHIR R4 Diagnostic Bundle</span>
            <span className="font-mono text-[11px] text-blue-600">ABDM Standard</span>
          </div>
          <pre className="text-xs text-slate-800 font-mono overflow-x-auto p-4 bg-slate-50 rounded-xl max-h-[500px] leading-relaxed border border-slate-200">
            {JSON.stringify(fhirBundle, null, 2)}
          </pre>
        </div>
      )}

      {/* Bottom Kiosk Restart Action */}
      <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl">
        <div className="text-xs text-slate-500">
          Ready for next patient intake.
        </div>
        <button
          type="button"
          onClick={onNewSession}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs py-2 px-4 rounded-xl transition-colors cursor-pointer"
        >
          Next Patient
        </button>
      </div>
    </div>
  );
}
