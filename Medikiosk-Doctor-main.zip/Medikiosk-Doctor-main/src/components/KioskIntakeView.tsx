import { useState, useEffect, useRef } from 'react';
import { MediKioskPayload, DepartmentType } from '../types';
import { speakPrompt, stopSpeaking, createSpeechRecognizer } from '../utils/speechUtils';
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Send,
  HelpCircle,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  Activity,
} from 'lucide-react';

interface KioskIntakeViewProps {
  payload: MediKioskPayload;
  onSendInput: (input: string) => Promise<void>;
  isLoading: boolean;
  department: DepartmentType;
  onCompleteIntake: () => void;
  onOpenOcr: () => void;
}

export default function KioskIntakeView({
  payload,
  onSendInput,
  isLoading,
  department,
  onCompleteIntake,
  onOpenOcr,
}: KioskIntakeViewProps) {
  const [inputText, setInputText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [audioAutoPlay, setAudioAutoPlay] = useState(false);
  const recognitionRef = useRef<any>(null);

  const spokenPrompt = payload.interaction_output?.spoken_prompt || '';
  const touchOptions = payload.interaction_output?.touch_options || [];
  const isAyush = department === 'AYUSH';

  // Autoplay TTS when a new spoken prompt arrives (only if opted-in)
  useEffect(() => {
    if (spokenPrompt && audioAutoPlay) {
      playAudio(spokenPrompt);
    }
    return () => {
      stopSpeaking();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (_e) {
          // ignore
        }
      }
    };
  }, [spokenPrompt, audioAutoPlay]);

  const playAudio = (text: string) => {
    try {
      stopSpeaking();
      setIsSpeaking(true);
      speakPrompt(
        text,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false),
        'hi-IN'
      ).catch((err) => {
        console.warn('playAudio error:', err);
        setIsSpeaking(false);
      });
    } catch (err) {
      console.warn('playAudio error:', err);
      setIsSpeaking(false);
    }
  };

  const toggleSpeech = () => {
    try {
      if (isSpeaking) {
        stopSpeaking();
        setIsSpeaking(false);
      } else if (spokenPrompt) {
        playAudio(spokenPrompt);
      }
    } catch (err) {
      console.warn('toggleSpeech error:', err);
      setIsSpeaking(false);
    }
  };

  // Toggle Sarvam Saaras v3 ASR (Speech Recognition)
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      (transcript: string) => {
        setInputText(transcript);
        setIsListening(false);
      },
      (err: any) => {
        console.warn('Speech recognition error/unsupported:', err);
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      },
      'hi-IN'
    );

    if (recognizer) {
      recognitionRef.current = recognizer;
      try {
        recognizer.start();
        setIsListening(true);
      } catch (e) {
        console.warn('Speech recognition start failed:', e);
        setIsListening(false);
      }
    } else {
      // Fallback hint
      setInputText('Mujhe bukhar aur pet me dard hai');
    }
  };

  const handleOptionClick = (option: string) => {
    if (isLoading) return;
    onSendInput(option);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendInput(inputText);
    setInputText('');
  };

  return (
    <div className="space-y-5">
      {/* Kiosk Dialogue Board */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-7 shadow-sm">
        {/* Audio Player Bar */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 mb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={toggleSpeech}
              className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
                isSpeaking
                  ? 'bg-amber-500 text-white shadow-md animate-pulse'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
              title={isSpeaking ? 'Stop Audio' : 'Play Voice'}
            >
              {isSpeaking ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>

            <div>
              <div className="text-xs font-semibold text-slate-800">
                {isSpeaking ? 'Audio Playing...' : 'Voice Assistant'}
              </div>
              <div className="text-[11px] text-slate-500">
                Indian English &amp; Hindi speech synthesis
              </div>
            </div>
          </div>

          {/* Audio Autoplay Switch */}
          <label className="text-xs text-slate-600 flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={audioAutoPlay}
              onChange={(e) => setAudioAutoPlay(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            Auto-speak questions
          </label>
        </div>

        {/* Current Active Question Display */}
        <div className="mb-6">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-semibold text-blue-600 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5" />
              {isAyush ? 'AYUSH Assessment' : 'Clinical Inquiry'}
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 sm:p-6">
            <h2 className="text-lg sm:text-xl font-semibold text-slate-900 tracking-tight leading-snug">
              {spokenPrompt ||
                (isAyush
                  ? 'Namaste. MediKiosk AYUSH OPD me aapka swagat hai. Kripya batayein aapko kya takleef hai?'
                  : 'Namaste. MediKiosk OPD me aapka swagat hai. Kripya batayein aapko kya pareshani hai?')}
            </h2>
          </div>
        </div>

        {/* Touch Options */}
        <div className="mb-6">
          <div className="text-xs font-semibold text-slate-500 mb-2.5">
            Select an option:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {touchOptions.length > 0 ? (
              touchOptions.map((opt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleOptionClick(opt)}
                  disabled={isLoading}
                  className="min-h-[52px] p-3.5 text-left bg-white hover:bg-blue-50/60 active:bg-blue-100/60 border border-slate-200 hover:border-blue-400 rounded-xl text-slate-800 font-medium text-sm sm:text-base transition-all flex items-center justify-between group shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  <span className="pr-3 leading-snug">{opt}</span>
                  <div className="w-6 h-6 rounded-md bg-slate-100 group-hover:bg-blue-600 flex items-center justify-center shrink-0 transition-colors">
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white" />
                  </div>
                </button>
              ))
            ) : (
              <div className="col-span-2 text-center p-4 text-slate-400 text-sm bg-slate-50 rounded-xl border border-slate-200">
                Please type or speak your response below.
              </div>
            )}
          </div>
        </div>

        {/* Voice Input & Text Input Bar */}
        <div>
          <form onSubmit={handleSubmit} className="flex gap-2">
            {/* Mic Button */}
            <button
              type="button"
              onClick={toggleListening}
              className={`p-3 rounded-xl border transition-all flex items-center justify-center shrink-0 cursor-pointer ${
                isListening
                  ? 'bg-red-50 text-red-600 border-red-300 animate-pulse'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
              title={isListening ? 'Stop listening' : 'Start speaking'}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Input field */}
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                isListening
                  ? 'Listening... Bolna shuru karein'
                  : 'Type in Hinglish or English (e.g. "Mujhe 3 din se bukhar hai")'
              }
              disabled={isLoading}
              className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading || !inputText.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition-colors flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shrink-0"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Quick test phrases */}
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-slate-400 font-medium">Quick examples:</span>
            <button
              type="button"
              onClick={() => setInputText('Mujhe 3 din se tez bukhar aur badan dard hai')}
              className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 transition-colors cursor-pointer"
            >
              Fever &amp; Body Pain
            </button>
            <button
              type="button"
              onClick={() => setInputText('Pet me jalan aur gas banti hai, khana pachta nahi')}
              className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 transition-colors cursor-pointer"
            >
              Dyspepsia
            </button>
            <button
              type="button"
              onClick={() => setInputText('Doctor sahab, mera Aadhaar 9876 5432 1098 hai, BP ki dawai chahiye')}
              className="text-xs bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors flex items-center gap-1 cursor-pointer"
              title="Tests automatic Aadhaar redaction"
            >
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Test Aadhaar Redaction
            </button>
            <button
              type="button"
              onClick={() => setInputText('Achanak chaati me bhari dabav aur left arm me dard ho raha hai')}
              className="text-xs bg-red-50 hover:bg-red-100 text-red-700 px-2.5 py-1 rounded-lg border border-red-200 transition-colors flex items-center gap-1 cursor-pointer"
              title="Tests emergency triage trigger"
            >
              <Activity className="w-3 h-3 text-red-600" />
              Test Emergency Alert
            </button>
          </div>
        </div>
      </div>

      {/* Auxiliary Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-white border border-slate-200 rounded-xl">
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <CheckCircle2 className="w-4 h-4 text-blue-600" />
          <span>FHIR R4 Aligned Intake</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenOcr}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            Scan Document
          </button>
          <button
            type="button"
            onClick={onCompleteIntake}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            View Summary
          </button>
        </div>
      </div>
    </div>
  );
}
