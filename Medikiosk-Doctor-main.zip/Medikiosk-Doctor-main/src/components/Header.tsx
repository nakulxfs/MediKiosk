import { DepartmentType } from '../types';
import { Stethoscope, Sparkles, RefreshCw, Layers, KeyRound } from 'lucide-react';

interface HeaderProps {
  department: DepartmentType;
  onDepartmentChange: (dept: DepartmentType) => void;
  onReset: () => void;
  onOpenScenarios: () => void;
  onOpenApiKeys: () => void;
  hasApiKey: boolean;
  activeMode: string;
}

export default function Header({
  department,
  onDepartmentChange,
  onReset,
  onOpenScenarios,
  onOpenApiKeys,
  hasApiKey,
}: HeaderProps) {
  return (
    <header className="bg-white border-b border-slate-200 text-slate-900 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-3">
          {/* Logo & Clean Title */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg leading-none">
              +
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-slate-900">
                  MediKiosk
                </h1>
                <span className="text-[11px] font-medium bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                  OPD
                </span>
              </div>
            </div>
          </div>

          {/* Department Switcher & Actions */}
          <div className="flex items-center gap-2">
            {/* Department Toggle */}
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200">
              <button
                type="button"
                onClick={() => onDepartmentChange('Allopathic')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  department === 'Allopathic'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
                Allopathic
              </button>
              <button
                type="button"
                onClick={() => onDepartmentChange('AYUSH')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  department === 'AYUSH'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                AYUSH
              </button>
            </div>

            {/* API Keys Configuration Button */}
            <button
              type="button"
              onClick={onOpenApiKeys}
              className={`text-xs font-medium px-2.5 sm:px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer border ${
                hasApiKey
                  ? 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200'
              }`}
              title="Configure Gemini & Sarvam API Keys"
            >
              <KeyRound className="w-3.5 h-3.5 text-current" />
              <span className="hidden sm:inline">{hasApiKey ? 'Keys Active' : 'Set Keys'}</span>
            </button>

            {/* Test Scenarios */}
            <button
              type="button"
              onClick={onOpenScenarios}
              className="bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-medium px-2.5 sm:px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Scenarios</span>
            </button>

            {/* Reset Session */}
            <button
              type="button"
              onClick={onReset}
              title="Reset"
              className="p-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 rounded-lg border border-slate-200 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
